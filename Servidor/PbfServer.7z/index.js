const http = require('http');
const geojsonvt = require('geojson-vt');
const vtpbf = require('vt-pbf');
const data = require('./apoyos.json');

// build the tile index from GeoJSON source data
const tileIndex = geojsonvt(data, {
    maxZoom: 20, // max zoom to preserve detail on; can't be higher than 24
    tolerance: 3, // simplification tolerance (higher means simpler)
    extent: 4096, // tile extent (both width and height)
    buffer: 64, // tile buffer on each side
    debug: 0, // logging level (0 to disable, 1 or 2)
    lineMetrics: false, // whether to enable line metrics tracking for LineString/MultiLineString features
    promoteId: null, // name of a feature property to promote to feature.id. Cannot be used with `generateId`
    generateId: false, // whether to generate feature ids. Cannot be used with `promoteId`
    indexMaxZoom: 5, // max zoom in the initial tile index
    indexMaxPoints: 100000 // max number of points per tile in the index
})


const port = process.env.PORT || 8080
http.createServer(handleRequest).listen(port)
console.log(`listening on port ${port}`)

// expects urls in the format: /{Z}/{X}/{Y}.pbf
function handleRequest(req, res) {
    const [z, x, y] = req.url
        .replace('.pbf', '')
        .split('/')
        .filter(n => n)
        .map(n => parseInt(n))

    // get the vectors for this tile
    const tile = tileIndex.getTile(z, x, y)

    // if there is no tile data, return an empty response
    if (!tile) {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*'
        })
        return res.end()
    }

    // encode as protobuf
    const buffer = Buffer.from(vtpbf.fromGeojsonVt({
        geojsonLayer: tile
    }))
    // write the buffer to the response stream
    res.writeHead(200, {
        'Content-Type': 'application/protobuf',
        'Access-Control-Allow-Origin': '*'
    })
    res.write(buffer, 'binary')
    res.end(null, 'binary')
}